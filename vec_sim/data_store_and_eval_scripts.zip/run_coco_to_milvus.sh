#!/bin/bash
nohup python3 -u coco_to_milvus.py > coco_to_milvus.log 2>&1 &